# Be sure to restart your server when you modify this file.

SEMCR::Application.config.session_store :cookie_store, key: '_SEMCR_session'
