class ImagenesEstablecimiento < ActiveRecord::Base
end
