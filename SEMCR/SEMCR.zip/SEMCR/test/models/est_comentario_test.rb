require 'test_helper'

class EstComentarioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
