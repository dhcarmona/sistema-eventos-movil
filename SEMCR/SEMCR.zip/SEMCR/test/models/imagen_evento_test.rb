require 'test_helper'

class ImagenEventoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
