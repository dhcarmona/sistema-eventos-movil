require 'test_helper'

class TipoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
