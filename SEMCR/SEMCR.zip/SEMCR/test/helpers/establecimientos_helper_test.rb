require 'test_helper'

class EstablecimientosHelperTest < ActionView::TestCase
end
