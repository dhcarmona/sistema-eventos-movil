require 'test_helper'

class EstComentariosHelperTest < ActionView::TestCase
end
