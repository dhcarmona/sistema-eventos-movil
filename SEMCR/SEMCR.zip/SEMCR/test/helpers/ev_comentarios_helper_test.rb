require 'test_helper'

class EvComentariosHelperTest < ActionView::TestCase
end
