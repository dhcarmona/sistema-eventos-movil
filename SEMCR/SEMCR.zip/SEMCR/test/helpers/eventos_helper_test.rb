require 'test_helper'

class EventosHelperTest < ActionView::TestCase
end
