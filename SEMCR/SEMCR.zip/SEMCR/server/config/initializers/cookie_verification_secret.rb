# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '5e8bc2fd6100cf673d22d2396676ebefd214555517551aa57b02021d1ef4f774645068579a8a3067a28d9ae2cee44ec632cbe1b850cd9cbba26a5a9c3d6bd944';
